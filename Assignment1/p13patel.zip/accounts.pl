%Kushal Dalal (kdalal) - 500828585
%Parth Patel (p13patel) - 500893723
%Hitarth Chudgar (hitarth.chudgar) - 500888845


hasAccount(ann,metro_credit_union,4000).
hasAccount(kushal,bank_of_montreal,5000).
hasAccount(kushal,national_bank_of_Canada,2000).
hasAccount(parth,toronto_dominion,3000).
hasAccount(hitarth,rbc,1100).
hasAccount(hitarth,toronto_dominion,1200).
hasAccount(bob,toronto_dominion,15000).
hasAccount(apurva,bmo,4000).
hasAccount(ashi,toronto_dominion,1350). 
created(shrey,royal_bank_of_canada,8,2019).
created(naeem,royal_bank_of_canada,8,2019).
created(hitarth,rbc,6,2019).
created(hitarth,toronto_dominion,6,2019).
created(kushal,bank_of_montreal,1,2001).
created(kushal,national_bank_of_Canada,2,2002).
created(bob,toronto_dominion,10,2019).
created(apurva,bmo,7,1978).
created(adolf,cibc,8,1941).
created(ann,metro_credit_union,6,1969).
lives(parth,kitchener).
lives(bob,new_york).
lives(hitarth,new_york).
lives(ashi,new_york).
lives(adolf,toronto).
